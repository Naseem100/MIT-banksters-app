package com.example.momentumdrawer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class AddGoal extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    String[] categories = {"Day","Week","Month"};
    String category = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_goal);

        final Spinner spinner = (Spinner) findViewById(R.id.spinner);

        //myEditor.putString("GOAL2", checkBox2.getText().toString());
        //myEditor.putString("GOAL3", checkBox3.getText().toString());
        //myEditor.putString("GOAL4", checkBox4.getText().toString());
        //myEditor.putString("GOAL5", checkBox5.getText().toString());
        //myEditor.putInt("GOAL1", Integer.parseInt(checkBox1.getText().toString()));
        //myEditor.putInt("GOAL2", Integer.parseInt(checkBox2.getText().toString()));
        //myEditor.putInt("GOAL3", Integer.parseInt(checkBox3.getText().toString()));
        //myEditor.putInt("GOAL4", Integer.parseInt(checkBox4.getText().toString()));
        //myEditor.putInt("GOAL5", Integer.parseInt(checkBox5.getText().toString()));

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
        spinner.setOnItemSelectedListener(this);

        final Button addGoal = (Button) findViewById(R.id.confirmGoal);
        addGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                EditText goal = (EditText) findViewById(R.id.goalAmount);

                SharedPreferences myPreferences = PreferenceManager.getDefaultSharedPreferences(AddGoal.this);
                SharedPreferences.Editor myEditor = myPreferences.edit();

                if(myPreferences.getInt("GOAL11", 3456) == 3456){
                    myEditor.putInt("GOAL11", Integer.parseInt(goal.getText().toString()));
                    myEditor.putString("GOALT1", category);
                }
                else if(myPreferences.getInt("GOAL22", 3456) == 3456){
                    myEditor.putInt("GOAL22", Integer.parseInt(goal.getText().toString()));
                    myEditor.putString("GOALT2", category);
                }
                else if(myPreferences.getInt("GOAL33", 3456) == 3456){
                    myEditor.putInt("GOAL33", Integer.parseInt(goal.getText().toString()));
                    myEditor.putString("GOALT3", category);
                }
                else{
                    myEditor.putInt("GOAL44", Integer.parseInt(goal.getText().toString()));
                    myEditor.putString("GOALT4", category);
                }
                myEditor.apply();
                startActivity(new Intent(AddGoal.this, Goals.class));
            }
        });
    }


    public void onItemSelected(AdapterView<?> arg0, View arg1, int position,long id) {
            category = categories[position];
    }


    public void onNothingSelected(AdapterView<?> arg0) {
// TODO Auto-generated method stub

    }
}
