package com.example.momentumdrawer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddACategory extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_acategory);

        Button addCategory = (Button) findViewById(R.id.confirmCategory);
        addCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText newCategory = (EditText) findViewById(R.id.newCategory);
                EditText oldCategory = (EditText) findViewById(R.id.oldCategory);
                EditText amount = (EditText) findViewById(R.id.amount);
                SharedPreferences myPreferences = PreferenceManager.getDefaultSharedPreferences(AddACategory.this);
                SharedPreferences.Editor myEditor = myPreferences.edit();

                if(myPreferences.getString("CATEGORY1", "") == ""){
                    myEditor.putString("CATEGORY1", newCategory.getText().toString());
                }
                else if(myPreferences.getString("CATEGORY2", "") == ""){
                    myEditor.putString("CATEGORY2", newCategory.getText().toString());
                }
                else if(myPreferences.getString("CATEGORY3", "") == ""){
                    myEditor.putString("CATEGORY3", newCategory.getText().toString());
                }
                else if(myPreferences.getString("CATEGORY4", "") == ""){
                    myEditor.putString("CATEGORY4", newCategory.getText().toString());
                }
                else if(myPreferences.getString("CATEGORY5", "") == ""){
                    myEditor.putString("CATEGORY5", newCategory.getText().toString());
                }
                else if(myPreferences.getString("CATEGORY1", "").equals(oldCategory.getText().toString())){
                    myEditor.putString("CATEGORY1", newCategory.getText().toString());
                    myEditor.putInt("AMOUNT1", Integer.parseInt(amount.getText().toString()));
                }
                else if(myPreferences.getString("CATEGORY2", "").equals(oldCategory.getText().toString())){
                    myEditor.putString("CATEGORY2", newCategory.getText().toString());
                    myEditor.putInt("AMOUNT2", Integer.parseInt(amount.getText().toString()));
                }
                else if(myPreferences.getString("CATEGORY3", "").equals(oldCategory.getText().toString())){
                    myEditor.putString("CATEGORY3", newCategory.getText().toString());
                    myEditor.putInt("AMOUNT3", Integer.parseInt(amount.getText().toString()));
                }
                else if(myPreferences.getString("CATEGORY4", "").equals(oldCategory.getText().toString())){
                    myEditor.putString("CATEGORY4", newCategory.getText().toString());
                    myEditor.putInt("AMOUNT4", Integer.parseInt(amount.getText().toString()));
                }
                else if(myPreferences.getString("CATEGORY5", "").equals(oldCategory.getText().toString())){
                    myEditor.putString("CATEGORY5", newCategory.getText().toString());
                    myEditor.putInt("AMOUNT5", Integer.parseInt(amount.getText().toString()));
                }

                if(myPreferences.getInt("AMOUNT1", 0) == 0){
                    myEditor.putInt("AMOUNT1", Integer.parseInt(amount.getText().toString()));
                }
                else if(myPreferences.getInt("AMOUNT2", 0) == 0){
                    myEditor.putInt("AMOUNT2", Integer.parseInt(amount.getText().toString()));
                }
                else if(myPreferences.getInt("AMOUNT3", 0) == 0){
                    myEditor.putInt("AMOUNT3", Integer.parseInt(amount.getText().toString()));
                }
                else if(myPreferences.getInt("AMOUNT4", 0) == 0){
                    myEditor.putInt("AMOUNT4", Integer.parseInt(amount.getText().toString()));
                }
                else if(myPreferences.getInt("AMOUNT5", 0) == 0){
                    myEditor.putInt("AMOUNT5", Integer.parseInt(amount.getText().toString()));
                }
                myEditor.commit();
                startActivity(new Intent(AddACategory.this, MonthlyBudget.class));
            }
        });
    }
}
