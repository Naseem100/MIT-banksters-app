package com.example.momentumdrawer;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.razerdp.widget.animatedpieview.AnimatedPieView;
import com.razerdp.widget.animatedpieview.AnimatedPieViewConfig;
import com.razerdp.widget.animatedpieview.callback.OnPieSelectListener;
import com.razerdp.widget.animatedpieview.data.IPieInfo;
import com.razerdp.widget.animatedpieview.data.SimplePieInfo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MonthlyBudget extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monthly_budget);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        final SharedPreferences myPreferences = PreferenceManager.getDefaultSharedPreferences(MonthlyBudget.this);
        String category1 = myPreferences.getString("CATEGORY1", "");
        String category2 = myPreferences.getString("CATEGORY2", "");
        String category3 = myPreferences.getString("CATEGORY3", "");
        String category4 = myPreferences.getString("CATEGORY4", "");
        String category5 = myPreferences.getString("CATEGORY5", "");
        Integer amount1 = myPreferences.getInt("AMOUNT1", 100);
        Integer amount2 = myPreferences.getInt("AMOUNT2", 100);
        Integer amount3 = myPreferences.getInt("AMOUNT3", 100);
        Integer amount4 = myPreferences.getInt("AMOUNT4", 0);
        Integer amount5 = myPreferences.getInt("AMOUNT5", 0);

        TextView cat1 = (TextView) findViewById(R.id.cat1);
        TextView cat2 = (TextView) findViewById(R.id.cat2);
        TextView cat3 = (TextView) findViewById(R.id.cat3);
        TextView cat4 = (TextView) findViewById(R.id.cat4);
        TextView cat5 = (TextView) findViewById(R.id.cat5);
        TextView am1 = (TextView) findViewById(R.id.amount1);
        TextView am2 = (TextView) findViewById(R.id.amount2);
        TextView am3 = (TextView) findViewById(R.id.amount3);
        TextView am4 = (TextView) findViewById(R.id.amount4);
        TextView am5 = (TextView) findViewById(R.id.amount5);

        cat1.setText(category1 + ":");
        cat2.setText(category2 + ":");
        cat3.setText(category3 + ":");
        cat4.setText(category4 + ":");
        cat5.setText(category5 + ":");
        am1.setText("$" + amount1.toString());
        am2.setText("$" + amount2.toString());
        am3.setText("$" + amount3.toString());
        am4.setText("$" + amount4.toString());
        am5.setText("$" + amount5.toString());

        AnimatedPieView animatedPieView = findViewById(R.id.pieView);
        AnimatedPieViewConfig config = new AnimatedPieViewConfig();
        config.addData(new SimplePieInfo(amount1, Color.parseColor("#AAFF0000"), category1));
        config.addData(new SimplePieInfo(amount2, Color.parseColor("#AA00FF00"), category2));
        config.addData(new SimplePieInfo(amount3, Color.parseColor("#AA0000FF"), category3));
        config.addData(new SimplePieInfo(amount4, Color.parseColor("#fd7300"), category4));
        config.addData(new SimplePieInfo(amount5, Color.parseColor("#6300ff"), category5));
        config.duration(1000);
        config.drawText(true);
        config.strokeMode(false);
        config.textSize(48);
        config.selectListener(new OnPieSelectListener<IPieInfo>(){
            @Override
            public void onSelectPie(@NonNull IPieInfo pieInfo, boolean isFloatUp){
                Toast.makeText(MonthlyBudget.this, pieInfo.getDesc() + "-" + pieInfo.getValue(), Toast.LENGTH_SHORT).show();
            }
        });
        config.startAngle(-180);
        animatedPieView.applyConfig(config);
        animatedPieView.start();

        FloatingActionButton addCategory = (FloatingActionButton) findViewById(R.id.addCategory);
        addCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MonthlyBudget.this, AddACategory.class));
            }
        });

        Button goHome = (Button) findViewById(R.id.goHomeBudget);
        goHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MonthlyBudget.this, MainActivity.class));
            }
        });


    }

}
