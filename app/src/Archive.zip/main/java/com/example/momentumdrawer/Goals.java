package com.example.momentumdrawer;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class Goals extends MainActivity {


    //private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goals);
        //Toolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);


        final SharedPreferences myPreferences = PreferenceManager.getDefaultSharedPreferences(Goals.this);
        final SharedPreferences.Editor myEditor = myPreferences.edit();
        Integer goal1 = myPreferences.getInt("GOAL11", 3456);
        Integer goal2 = myPreferences.getInt("GOAL22", 3456);
        Integer goal3 = myPreferences.getInt("GOAL33", 3456);
        Integer goal4 = myPreferences.getInt("GOAL44", 3456);
        String goalt1 = myPreferences.getString("GOALT1", "");
        String goalt2 = myPreferences.getString("GOALT2", "");
        String goalt3 = myPreferences.getString("GOALT3", "");
        String goalt4 = myPreferences.getString("GOALT4", "");
        final CheckBox checkBox1 = (CheckBox) findViewById(R.id.checkBox);
        final CheckBox checkBox2 = (CheckBox) findViewById(R.id.checkBox2);
        final CheckBox checkBox3 = (CheckBox) findViewById(R.id.checkBox3);
        final CheckBox checkBox4 = (CheckBox) findViewById(R.id.checkBox4);

        if(goal1 != 3456){
            checkBox1.setText("Save $" + goal1.toString() + " every " + goalt1.toLowerCase());
        }
        if(goal2 != 3456){
            checkBox2.setText("Save $" + goal2.toString() + " every " + goalt2.toLowerCase());
        }
        if(goal3 != 3456){
            checkBox3.setText("Save $" + goal3.toString() + " every " + goalt3.toLowerCase());
        }
        if(goal4 != 3456){
            checkBox4.setText("Save $" + goal4.toString() + " every " + goalt4.toLowerCase());
        }

        FloatingActionButton addGoal = (FloatingActionButton) findViewById(R.id.addGoal);
        addGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Goals.this, AddGoal.class));
            }
        });

        Button achieve = (Button) findViewById(R.id.achievements);
        achieve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Goals.this, Achievements.class));
            }
        });

        Button goHome = (Button) findViewById(R.id.goHome);
        goHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer currLvl = myPreferences.getInt("LVL", 0);
                if(checkBox1.isChecked() && checkBox1.getText().toString() != ""){
                    checkBox1.setText("");
                    currLvl += 1;
                    myEditor.putInt("GOAL11", 3456);
                    myEditor.putString("GOALT1", "");
                }
                if(checkBox2.isChecked() && checkBox2.getText().toString() != ""){
                    checkBox2.setText("");
                    currLvl += 1;
                    myEditor.putInt("GOAL22", 3456);
                    myEditor.putString("GOALT2", "");
                }
                if(checkBox3.isChecked() && checkBox3.getText().toString() != ""){
                    checkBox3.setText("");
                    currLvl += 1;
                    myEditor.putInt("GOAL33", 3456);
                    myEditor.putString("GOALT3", "");
                }
                if(checkBox4.isChecked() && checkBox4.getText().toString() != ""){
                    checkBox4.setText("");
                    currLvl += 1;
                    myEditor.putInt("GOAL44", 3456);
                    myEditor.putString("GOALT4", "");
                }
                myEditor.putInt("LVL", currLvl);
                myEditor.putInt("COINS", currLvl*20);
                myEditor.commit();
                startActivity(new Intent(Goals.this, MainActivity.class));
            }
        });
    }


}
