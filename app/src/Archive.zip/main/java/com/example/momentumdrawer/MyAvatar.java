package com.example.momentumdrawer;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MyAvatar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_avatar);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        SharedPreferences myPreferences = PreferenceManager.getDefaultSharedPreferences(MyAvatar.this);
        TextView currCoins = (TextView) findViewById(R.id.currCoins);
        Integer coins = myPreferences.getInt("COINS", 0);
        currCoins.setText(coins.toString() + " coins");

        Button goRewards = (Button)findViewById(R.id.gotoRewards);
        goRewards.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MyAvatar.this, Rewards.class));
            }
        });

        Button goShop = (Button)findViewById(R.id.goAvatarShop);
        goShop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MyAvatar.this, AvatarShop.class));
            }
        });
    }

}
