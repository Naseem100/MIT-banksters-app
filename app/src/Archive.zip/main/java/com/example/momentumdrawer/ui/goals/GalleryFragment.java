package com.example.momentumdrawer.ui.goals;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.momentumdrawer.AddGoal;
import com.example.momentumdrawer.ChTransactions;
import com.example.momentumdrawer.Goals;
import com.example.momentumdrawer.MainActivity;
import com.example.momentumdrawer.R;
import com.example.momentumdrawer.SavTransactions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class GalleryFragment extends Fragment {

    private GalleryViewModel galleryViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        startActivity(new Intent(getActivity(), com.example.momentumdrawer.Goals.class));
        galleryViewModel =
                ViewModelProviders.of(this).get(GalleryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_goals, container, false);
        return root;

    }
}