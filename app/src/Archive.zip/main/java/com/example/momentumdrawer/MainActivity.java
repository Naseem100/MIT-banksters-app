package com.example.momentumdrawer;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.preference.PreferenceManager;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    LinearLayout progressBar = null;
    LinearLayout progressBarOG = null;


    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_goals, R.id.nav_monthly_budget,
                R.id.nav_avatar_shop, R.id.nav_share, R.id.nav_send)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);



        SharedPreferences myPreferences = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        TextView fullName1 = (TextView)findViewById(R.id.userName1);
        String userName1  = myPreferences.getString("NAME", "unknown");
        if(userName1.length() < 12) {
            String newUserName = String.format("%22s",userName1);
            Log.d("username", newUserName);
            fullName1.setText(newUserName);
        }
        else{
            fullName1.setText(userName1);
        }
        TextView checkingAmount = (TextView)findViewById(R.id.checkAmount);
        TextView savingAmount = (TextView)findViewById(R.id.savingAmount);
        Integer chAmount = myPreferences.getInt("CHECKING", 0);
        Integer savAmount = myPreferences.getInt("SAVINGS", 0);
        checkingAmount.setText(chAmount.toString());
        savingAmount.setText(savAmount.toString());
        TextView lvl = (TextView)findViewById(R.id.userLvl);
        TextView coins = (TextView)findViewById(R.id.coins);
        Integer userLvl = myPreferences.getInt("LVL", 0);
        Integer userCoins = myPreferences.getInt("COINS", 80);
        coins.setText(userCoins.toString());
        lvl.setText("Level " + userLvl.toString());


        Button btnChecking = (Button)findViewById(R.id.checking);
        btnChecking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ChTransactions.class));
            }
        });
        Button btnSavings = (Button)findViewById(R.id.saving);
        btnSavings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SavTransactions.class));
            }
        });



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        SharedPreferences myPreferences = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        TextView fullName2 = (TextView)findViewById(R.id.userName2);
        TextView fullEmail = (TextView)findViewById(R.id.userEmail);
        String userName  = myPreferences.getString("NAME", "unknown");
        String userEmail  = myPreferences.getString("EMAIL", "unknown");
        fullName2.setText(userName);
        fullEmail.setText(userEmail);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }


}
